#pragma once
#include "Student.h"

/*Following Code is for Question 01*/
ostream& operator<<(ostream&, const Student& );
