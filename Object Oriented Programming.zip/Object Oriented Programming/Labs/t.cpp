class AA {



};

class BB :public AA {


};

class CC : public BB {


};

class DD : public CC {


};