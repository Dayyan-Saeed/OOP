#include <iostream>

using namespace std;


class Person {
    
private:
    string name;
    int age{};
    char gender{};
public:
    
    void setName(string pName) {
        name = std::move(pName);
    }

    void setAge(int pAge) {
        age = pAge;
    }

    void setGender(char pGender) {
        gender = pGender;
    }

   
    string getName() {
        return name;
    }

    [[nodiscard]] int getAge() const {
        return age;
    }

    [[nodiscard]] char getGender() const {
        return gender;
    }
};

class Employee {
private:
    string employerName;
    float dailyWages{};
public:

    void setEmployerName(string eName) {
        employerName = std::move(eName);
    }

    void setDailyWages(float dWage) {
        dailyWages = dWage;
    }

    string getEmployerName() {
        return employerName;
    }

    [[nodiscard]] float getDailyWages() const {
        return dailyWages;
    }
};

class Teacher : public Person, public Employee {

private:
    string teacherGrade;
public:
    
    void setTeacherGrade(string grade) {
        teacherGrade = std::move(grade);
    }

    
    string getTeacherGrade() {
        return teacherGrade;
    }
};

int main() {

    Teacher t;

    t.setName("Tom Jonson");
    t.setAge(42);
    t.setGender('M');

    t.setEmployerName("Thomas Mathew");
    t.setDailyWages(100);

    t.setTeacherGrade("grade 3");

    cout << "Teacher t's information..." << endl;
    cout << "Teacher t's name: " << t.getName() << endl;
    cout << "Teacher t's age: " << t.getAge() << endl;
    cout << "Teacher t's gender: " << t.getGender() << endl;
    cout << "Teacher t's employer name: " << t.getEmployerName() << endl;
    cout << "Teacher t's daily wages: $" << t.getDailyWages() << endl;
    cout << "Teacher t's grade: " << t.getTeacherGrade() << endl;
    return 0;
}