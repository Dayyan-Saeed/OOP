#include<iostream>
#include<ctime>
#include "classt2.h"
using namespace std;


void employee::constructor(int _employeeCode, int _ageAtJoining, int _currentAge){


	employeeCode=_employeeCode;
	ageAtJoining=_ageAtJoining;
	currentAge=_currentAge;

	display(employeeCode, ageAtJoining, currentAge);
}



void employee::display(int _employeeCode, int _ageAtJoining, int _currentAge){

	cout << employeeCode << endl;
	cout << ageAtJoining << endl;
	cout << currentAge << endl;
}



void  employee::calculateTenure(int empcode, int agej, int agec,int tenure){


	tenure = agej - agec;

	cout << "Tenure: " << tenure;

}