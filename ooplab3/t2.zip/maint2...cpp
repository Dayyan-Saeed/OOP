#include<iostream>

#include "classt2.h"

using namespace std;


int main(){

	employee emp1;
	int empcode1, agej1, agec1, tenure1;

	cout << "Enter Employee code: ";
	cin >> empcode1;
	cout << "Enter age at joining: ";
	cin >> agej1;
	cout << "Enter current age: ";
	cin >> agec1;

	emp1.constructor(empcode1,agej1,agec1);
	emp1.dislpay(empcode1, agej1, agec1);
	emp1.calculateTenure(empcode1, agej1, agec1, tenure1);

	employee emp2;
	int empcode2, agej2, agec2, tenure2;

	cout << "Enter Employee code: ";
	cin >> empcode2;
	cout << "Enter age at joining: ";
	cin >> agej2;
	cout << "Enter current age: ";
	cin >> agec2;

	emp2.constructor(empcode2, agej2, agec2);
	emp2.dislpay(empcode2, agej2, agec2);
	emp2.calculateTenure(empcode2, agej2, agec2, tenure2);


	employee emp3;
	int empcode3, agej3, agec3, tenure3;

	cout << "Enter Employee code: ";
	cin >> empcode3;
	cout << "Enter age at joining: ";
	cin >> agej3;
	cout << "Enter current age: ";
	cin >> agec3;

	emp3.constructor(empcode3, agej3, agec3);
	emp3.dislpay(empcode3, agej3, agec3);
	emp3.calculateTenure(empcode3, agej3, agec3, tenure3);


	employee emp4;
	int empcode4, agej4, agec4, tenure4;

	cout << "Enter Employee code: ";
	cin >> empcode4;
	cout << "Enter age at joining: ";
	cin >> agej4;
	cout << "Enter current age: ";
	cin >> agec4;

	emp4.constructor(empcode4, agej4, agec4);
	emp4.dislpay(empcode4, agej4, agec4);
	emp4.calculateTenure(empcode4, agej4, agec4, tenure4);


	

}