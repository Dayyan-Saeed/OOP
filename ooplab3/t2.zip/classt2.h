class employee{

	int employeeCode;
	int ageAtJoining;
	int currentAge;
public:
	void constructor(int , int, int);
	void display(int, int, int);
	void calculateTenure(int, int, int,int);
};