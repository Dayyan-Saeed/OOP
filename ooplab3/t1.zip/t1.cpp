#include<iostream>
#include<ctime>
#include "classt1.h"
using namespace std;

void Date::init(int _day, int _month, int _year){
	day = _day;
	month = _month;
	year = _year;
	display(day, month, year);
}

void Date::display(int _day, int _month, int _year){
	cout << day << "-" << month << "-" << year << endl;
}

void Date::age(int datenow, int datethen, int monthnow, int monththen, int yearnow, int yearthen){
	int month[] = { 31, 28, 31, 30, 31, 30,
		31, 31, 30, 31, 30, 31 };

	if (datethen > datenow) {
		datenow = datenow + month[monththen - 1];
		monthnow = monthnow - 1;
	}

	if (monththen > monthnow) {
		yearnow = yearnow - 1;
		monthnow = monthnow + 12;
	}

	int age_in_date = datenow - datethen;
	int age_in_month = monthnow - monththen;
	int age_in_year = yearnow - yearthen;
	cout << "Your age is " << age_in_year << " years, " << age_in_month << " months and  " << age_in_date << " days." << endl;
}