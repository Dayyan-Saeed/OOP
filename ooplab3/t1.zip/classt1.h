class Date{
private:
	int day, month, year;

public:
	void init(int, int, int);
	void display(int, int, int);
	void age(int, int, int, int, int, int);
};