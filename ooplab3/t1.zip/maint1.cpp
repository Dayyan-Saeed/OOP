#include<iostream>

#include "classt1.h"

using namespace std;

int main(){
	Date dat;
	int d, d1, m, m1, y, y1;
	cout << "Please Enter your Date of Birth : ";
	cin >> d;
g:cout << "Please Enter your Month of Birth : ";
	cin >> m;
	if (m < 0){
		while (1){
			goto g;
		}
	}
	cout << "Please Enter your Year of Birth : ";
	cin >> y;
	cout << endl;
	cout << "Date of Birth :";
	dat.init(d, m, y);
	cout << "------------------------------------------------------------" << endl;

	cout << "Please Enter Current Date : ";
	cin >> d1;
g1: cout << "Please Enter Current Month : ";
	cin >> m1;
	if (m1 < 0){
		while (1){
			goto g1;
		}
	}
	cout << "Please Enter Current Year : ";
	cin >> y1;
	cout << endl;
	cout << "Current Date :";
	dat.init(d1, m1, y1);
	cout << "------------------------------------------------------------" << endl;
	dat.age(d1, d, m1, m, y1, y);

}