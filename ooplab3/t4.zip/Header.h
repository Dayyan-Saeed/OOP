
#pragma once

class complex {

	int real;
	int imag;

	void setdvalue();
	void display();
	void sum();




};