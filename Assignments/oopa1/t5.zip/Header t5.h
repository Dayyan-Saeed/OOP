#pragma once
class Complex {

private:
    double real, imag;

public:
    Complex(); 
    Complex(double r); 
    Complex(double r, double i); 
    Complex(Complex& obj); 
    Complex add(Complex c); 
    Complex sub(Complex c); 
    Complex mult(Complex c); 
    Complex div(Complex c); 
    void print();
    double getReal(); 
    double getImag(); 
    void setReal(double re); 
    void setImag(double im);
       

};
