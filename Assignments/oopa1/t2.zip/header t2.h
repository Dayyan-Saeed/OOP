#pragma once
#include <string>
class Invoice
{
private:
	string partNumber;
	string partDescription;
	int itemQuantity;
	int itemPrice;

public:
	Invoice(string, string, int, int);
	void setPartNumber(string);
	string getPartNumber();
	void setPartDescription(string);
	string getPartDescription();
	void setItemQuantity(int);
	int getItemQuantity();
	void setItemPrice(int);
	int getItemPrice();
	int getInvoiceAmount();

};
