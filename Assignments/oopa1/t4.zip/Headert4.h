
class Time
{
public:
	Time();
	Time(int, int, int);
	void Display();
private:
	int hour, minute, second;
};

