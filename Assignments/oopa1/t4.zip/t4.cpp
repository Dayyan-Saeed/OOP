#include "Headert4.h"
#include <ctime>
#include <iostream>

using namespace std;

Time::Time()
{
    time_t currenttime;
    struct tm timeinfo;
    time(&currenttime);
    localtime_s(&timeinfo, &currenttime);
    hour = timeinfo.tm_hour;
    minute = timeinfo.tm_min;
    second = timeinfo.tm_sec;
}

Time::Time(int h, int m, int s) :
    hour(h), minute(m), second(s)
{
}

void Time::Display()
{
	cout << hour << ":" << minute << ":" << second << endl;
}