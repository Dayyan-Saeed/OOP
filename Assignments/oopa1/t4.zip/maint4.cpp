#include <iostream>
#include <ctime>
#include "Headert4.h"

int main()
{
    Time currentTime;

    currentTime.Display();

    system("pause");
    return 0;
}