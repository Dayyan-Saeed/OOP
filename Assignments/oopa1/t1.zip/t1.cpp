#include<iostream>
#include"Header t1.h"
using namespace std;


Account::Account(int amount)
	{
		
		if (amount < 0)
		{
			
			accountbalance = 0;
			cout << "Initial balance was invalid." << endl;
		}
		else
			accountbalance = amount;
	}
	
	void Account::credit(int amount)
	{
		accountbalance = accountbalance + amount;
	}
	
	void Account::debit(int amount)
	{
		if (amount > accountbalance)
			cout << "Debit amount exceeded account balance." << endl;
		else
			
			accountbalance = accountbalance - amount;
	}
	
	int Account::getBalance()
	{
		return accountbalance;
	}
 
