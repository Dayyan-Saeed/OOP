#include<iostream>
#include"Header t1.h"
using namespace std;


int main()
{
	int x = 0, y = 0, ac1 = 0;

	cout << "Enter Account 1 balance: ";
	cin >> ac1;
	Account act1(ac1); 

	cout << endl;
	cout << "Enter Credit to balance: ";
	cin >> x;
	act1.credit(x);
	cout << "Account 1 balance: " << act1.getBalance() << endl;
	cout << "Enter Debit from balance: ";
	cin >> y;
	act1.debit(y);
	cout << "Account 1 balance: " << act1.getBalance() << endl;
	cout << endl << endl;

	int a, b, ac2;

	cout << "Enter Account 2 balance: ";
	cin >> ac2;;
	Account act2(ac2);
	cout << endl;
	cout << "Enter Credit to balance: ";
	cin >> a;
	act2.credit(a);
	cout << "Account 2 balance: " << act2.getBalance() << endl;
	cout << "Enter Debit from balance: ";
	cin >> b;
	act2.debit(b);
	cout << "Account 2 balance: " << act2.getBalance() << endl;
	cout << endl;

	system("pause");
	return 0;
}