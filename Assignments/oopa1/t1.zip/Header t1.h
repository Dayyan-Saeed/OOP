class Account
{
private:

	int accountbalance;

public:
	
	Account(int amount);
	void credit(int amount);
	void debit(int amount);
	int getBalance();
	
};