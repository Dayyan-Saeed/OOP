#pragma once
#include <iostream>
#include <string.h>
#ifndef Employee_h
#define Employee_h

using namespace std;

class Employee
{
private:
	// variable to store name and salary
	string FirstName;
	string LastName;
	int Salary;

public:
	Employee();
	void setFirstName(string name);// set the Employee name
	string getFirstName();// get employee name
	void setLastName(string lastname);// set the LastName
	string getLastName();// get the LastName
	void setSalary(int salary);// set employee salary
	int getSalary();// get the Salary

};
#endif

// Employee.cpp
#include <iostream>
#include <string.h>
#ifndef Employee_h
#define Employee_h

using namespace std;

class Employee
{
private:
	// variable to store name and salary
	string FirstName;
	string LastName;
	int Salary;

public:
	Employee();
	void setFirstName(string name);// set the Employee name
	string getFirstName();// get employee name
	void setLastName(string lastname);// set the LastName
	string getLastName();// get the LastName
	void setSalary(int salary);// set employee salary
	int getSalary();// get the Salary

};
#endif