#include <iostream>
#include <vector>
#include <string>

#include "Headert5.h"

using namespace std;

int main()
{
    //Vector to hold employee details
    vector<Employee> employees;
    string fname, lname;
    int salary;
    int i;
    int most = 0, least = 0;

    //Loop till user enters QUIT
    while (1)
    {
        //Reading first name
        cout << "\n\n Enter First Name: ";
        cin >> fname;

        //Reading last name
        cout << "\n Enter Last Name: ";
        cin >> lname;

        //If name == QUIT
        if ((strcmp(fname.c_str(), "QUIT") == 0) || (strcmp(lname.c_str(), "QUIT") == 0))
        {
            break;
        }

        //Reading salary
        cout << "\n Enter Salary (month): ";
        cin >> salary;

        //Employee object
        Employee temp;

        //Setting First name, Last name, Salary
        temp.setFirstName(fname);
        temp.setLastName(lname);
        temp.setSalary(salary);

        //Adding employee object to vector
        employees.push_back(temp);
    }

    cout << "\n\n Employee details: \n";

    //Looping over vector and printing employee details
    for (i = 0; i < employees.size(); i++)
    {
        cout << "\n Yearly salary of " << employees[i].getFirstName() << " " << employees[i].getLastName() << " is " << 12 * employees[i].getSalary() << endl;

        //Identifying employee with most salary
        if (employees[i].getSalary() > employees[most].getSalary())
            most = i;

        //Identifying employee with least salary
        if (employees[i].getSalary() < employees[least].getSalary())
            least = i;
    }

    cout << "\n\n Employee With Most Salary: \n ";
    cout << "Yearly salary of " << employees[most].getFirstName() << " " << employees[most].getLastName() << " is " << 12 * employees[most].getSalary() << endl;

    cout << "\n\n Employee With Least Salary: \n ";
    cout << "Yearly salary of " << employees[least].getFirstName() << " " << employees[least].getLastName() << " is " << 12 * employees[least].getSalary() << endl;


    cout << "\n\n Employee details after 10% Hike in Salary: \n";

    //Increase salary by 10% and printing details
    for (i = 0; i < employees.size(); i++)
    {
        //Increasing salary by 10%
        employees[i].setSalary(employees[i].getSalary() + (employees[i].getSalary() * 0.1));
        cout << "\n Yearly salary of " << employees[i].getFirstName() << " " << employees[i].getLastName() << " is " << 12 * employees[i].getSalary() << endl;
    }

    cout << "\n\n";
    return 0;
}