#include <iostream>
#include <string.h>
#include "Headert5.h"
using namespace std;

Employee::Employee()
{
    FirstName = "ayush";
    LastName = "verma";
    Salary = 100000;
}

void Employee::setFirstName(string name)
{
    FirstName = name;
}

string Employee::getFirstName()
{
    return FirstName;
}

void Employee::setLastName(string lastName)
{
    LastName = lastName;
}

string Employee::getLastName()
{
    return LastName;
}

void Employee::setSalary(int salary)
{
    if (salary < 0)
        Salary = 0;
    else
        Salary = salary;
}

int Employee::getSalary()
{
    return Salary;
}




